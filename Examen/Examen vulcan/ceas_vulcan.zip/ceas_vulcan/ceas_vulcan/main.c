/*
 * ceas_vulcan.c
 *
 * Created: 6/16/2021 7:25:34 PM
 * Author : John
 */ 
/*

 Tr=0,75s  fclk_cpu = 4MHz
 fclk_cpu Tr = k p N
 4 10^6 75 10^-2 = 4 75 10^4 = 3 10^6 = 2^6 3 5^6
 Alegem cel mai mare p = 2^6
 Cel mai mic k => k=1
 Ramane N= 3 5^6 = 46875
 N> 256 => timer 1: p=64, mode CTC, N= 46875  1 punct
 
   //          ________ CTC (Mode 0100)
   //          || 
   TCCR1B=0b00 01 011;
   //             ||| 
   //             ----clkIO/64
   //
   //              ________ CTC (Mode 0100)
   //              ||
   TCCR1A=0b000000 00;

   OCR1A=46875-1; 

   inca 0.5 puncte
   Total 1.5 puncte

*/
#include <avr/io.h>

char vor=0, vin=0, vec=0;
//schema LED-uri timp vulacan 0.5 puncte (vezi ceas_vulcan.simu)
void show_vtime(){
   char temp1, temp2;
   //             0        1       2      3       4        5      6       7
   //             dcba
   char abcd[]={0b1111, 0b0100, 0b0110, 0b1100, 0b1110, 0b1101, 0b1011, 0b0111};  //definire LUT 0.5 puncte
       
   temp1 = abcd[vec%8];      // 
   temp2 = abcd[vec/8]<<4;   //  1.5 puncte
   PORTA = temp1 | temp2;    //
      
   temp1 = abcd[vin%8];      //
   temp2 = abcd[vin/8]<<4;   //  0.5 puncte
   PORTB = temp1 | temp2;    //

   temp1 = abcd[vor%8];      //
   temp2 = abcd[vor/8]<<4;   //  0.5 puncte. Total 3.5 puncte. Neconcordanta intre schema si cod diminueaza punctajul
   PORTC = temp1 | temp2;    //
}

int main(void){
   char status=0, sa=0xff, sn, lc=0;
   //aici incep initializarile 
   TCCR1B=0b0001011;
   TCCR1A=0b00000000;
   OCR1A=46875-1;
   
   DDRA=DDRB=DDRC=0xff;
   DDRD=1;
   // aici se termina initializarile  0.5 puncte pentru initializari + schema push butoane si ledul L  (vezi ceas_vulcan.simu)
   
    while (1){
      if(lc==5){ // 5 sau alta valoare
         lc=0;
         sa=sn;
         sn=PIND;
         if( (sa & 1<<4)==0  && (sn & 1<<4)){ //
            status^=1;                        //
            vec=0;                            // 0.5 puncte
            PORTD=status;                     //
         }
         
         if( (sa & 1<<5)==0  && (sn & 1<<5))  //
            vin=(vin+1) % 56;                 // 0.5 puncte
         
         if( (sa & 1<<6)==0  && (sn & 1<<6))  //
            vor=(vor+1) % 16;                 // 0.5 puncte
      }
      
      if(status==0){//RUN 
         if(TIFR & 1<<OCF1A){ //
            TIFR |= 1<<OCF1A; // 0.5 puncte
         
            vec++;         //
            if(vec == 64){ // 0.5 puncte
               vec=0;      //
               vin++;      // 
            }
         
            if(vin==56){  //
               vin=0;     // 0.5 puncte
               vor++;     //
            }
         
            if(vor==16) //
               vor=0;   // 0.5 puncte
          }//end TIFR
      }//end status ==0       
      show_vtime();
      lc++;
    }//end while    
    //total 4 puncte
    //Neconcordanta intre schema si cod diminueaza punctajul
    //Integrarea incorecta a operatiilor de mai sus diminueaza punctajul. De exemplu tratarea incorecta a lui:
    //  -lc     -0.5 
    //  -sa, sn -0.5
    // - status -0.5
}